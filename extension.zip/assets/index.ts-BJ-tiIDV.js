import{g as x,i as u,u as b}from"./utils-Bs0wOLma.js";let o=null,c=null,f=!1;const h=async()=>{if(console.log("Starting modal creation..."),o){console.log("Modal already exists, skipping creation");return}const e=await x();if(console.log("Extension state:",e),!e.enabled){console.log("Extension is disabled");return}if(e.apps.length===0){console.log("No tools configured");return}if(u(window.location.href)){console.log("Current site is an AI website, skipping");return}const n=window.location.hostname,l=e.lastShownDomain||"",p=e.lastShown||0,g=Date.now();if(n===l&&g-p<5*60*1e3){console.log("Modal shown recently on this domain, skipping");return}f=!1,o=document.createElement("div"),o.id="ai-prompt-reminder-modal",o.style.cssText=`
    position: fixed !important;
    top: 0 !important;
    right: 0 !important;
    left: 0 !important;
    bottom: 0 !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
    display: flex !important;
    justify-content: flex-end !important;
    align-items: flex-start !important;
    padding: 40px !important;
  `;const i=o.attachShadow({mode:"closed"}),s=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches,t=e.theme==="dark"||e.theme==="system"&&s,a=document.createElement("style");a.textContent=`
    .modal-container {
      position: relative;
      pointer-events: auto;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    }
    
    .modal-content {
      background: ${t?"#1f2937":"#ffffff"};
      border-radius: 16px;
      box-shadow: 0 25px 50px -12px ${t?"rgba(0, 0, 0, 0.6)":"rgba(0, 0, 0, 0.15)"}, 
                  0 10px 25px -5px ${t?"rgba(0, 0, 0, 0.4)":"rgba(0, 0, 0, 0.08)"};
      border: 1px solid ${t?"rgba(75, 85, 99, 0.3)":"rgba(229, 231, 235, 0.5)"};
      width: 320px;
      height: 120px;
      padding: 0;
      position: relative;
      animation: smoothSlideIn 0.8s cubic-bezier(0.23, 1, 0.32, 1);
      overflow: visible;
      backdrop-filter: blur(12px);
      display: flex;
      flex-direction: row;
      margin-top: 0;
    }
    
    @keyframes smoothSlideIn {
      0% { 
        opacity: 0; 
        transform: translateX(60px) translateY(-15px) scale(0.85);
      }
      40% {
        opacity: 0.6;
        transform: translateX(10px) translateY(-5px) scale(0.92);
      }
      70% {
        opacity: 0.9;
        transform: translateX(-2px) translateY(2px) scale(0.98);
      }
      100% { 
        opacity: 1; 
        transform: translateX(0) translateY(0) scale(1); 
      }
    }
    
    .modal-header {
      position: absolute;
      top: 8px;
      right: 8px;
      z-index: 10;
    }
    
    .close-btn {
      background: ${t?"rgba(156, 163, 175, 0.1)":"rgba(107, 114, 128, 0.1)"};
      border: none;
      color: ${t?"#9ca3af":"#6b7280"};
      cursor: pointer;
      padding: 6px;
      border-radius: 6px;
      transition: all 0.2s ease;
      font-size: 12px;
      line-height: 1;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .close-btn:hover {
      background: ${t?"rgba(156, 163, 175, 0.15)":"rgba(107, 114, 128, 0.15)"};
      color: ${t?"#d1d5db":"#374151"};
      transform: scale(1.05);
    }
    
    .main-question {
      flex: 1;
      padding: 20px 24px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      position: relative;
    }
    
    .question-text {
      color: ${t?"#f9fafb":"#111827"};
      font-size: 18px;
      font-weight: 700;
      line-height: 1.25;
      margin-bottom: 40px;
      letter-spacing: -0.02em;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .tools-dropdown {
      position: absolute;
      bottom: 8px;
      left: 24px;
      z-index: 1;
    }
    
    .ai-badge {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 2px 6px;
      border-radius: 5px;
      font-size: 8px;
      font-weight: 600;
      margin-bottom: 12px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      width: fit-content;
    }
    
    .ai-icon {
      width: 7px;
      height: 7px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 2px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 5px;
      font-weight: bold;
    }
    
    .divider {
      width: 1px;
      background: ${t?"linear-gradient(180deg, transparent, rgba(75, 85, 99, 0.3), transparent)":"linear-gradient(180deg, transparent, #e5e7eb, transparent)"};
      margin: 16px 0;
    }
    
    .tools-section { /* Right-hand section, currently empty but kept for structure */
      padding: 20px 24px 20px 16px;
      display: flex;
      flex-direction: column;
      justify-content: flex-end; /* Align content (like dismiss button via footer) to bottom */
      min-width: 120px; /* Ensures it takes up some space */
    }
    
    .tools-trigger {
      background: none;
      border: none;
      padding: 6px 0;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      cursor: pointer;
      transition: all 0.2s ease;
      font-size: 10px;
      color: ${t?"#9ca3af":"#6b7280"};
      border-radius: 4px;
      text-align: left;
    }
    
    .tools-trigger:hover {
      background: ${t?"rgba(156, 163, 175, 0.05)":"rgba(107, 114, 128, 0.05)"};
      color: ${t?"#d1d5db":"#374151"};
    }
    
    .tools-trigger-text {
      margin-right: 6px;
    }
    
    .tools-icon {
      font-size: 7px;
      transition: transform 0.2s ease;
    }
    
    .tools-icon.open {
      transform: rotate(180deg);
    }
    
    .tools-content {
      display: none;
      position: absolute;
      top: 100%;
      bottom: auto;
      left: 0;
      right: auto;
      background: ${t?"#1f2937":"#ffffff"};
      border-radius: 8px;
      box-shadow: 0 8px 16px ${t?"rgba(0,0,0,0.3)":"rgba(0,0,0,0.1)"};
      border: 1px solid ${t?"rgba(75, 85, 99, 0.3)":"rgba(229, 231, 235, 0.5)"};
      margin-top: 4px;
      padding: 8px;
      min-width: 220px;
      z-index: 1000;
      animation: slideDown 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    .tools-content.open {
      display: block;
    }
    
    @keyframes slideDown {
      from { 
        opacity: 0; 
        transform: translateY(-8px); 
      }
      to { 
        opacity: 1; 
        transform: translateY(0); 
      }
    }
    
    .app-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
      max-height: 150px;
      overflow-y: auto;
    }
    
    .app-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 10px;
      border: 1px solid ${t?"rgba(75, 85, 99, 0.3)":"rgba(229, 231, 235, 0.6)"};
      border-radius: 6px;
      background: ${t?"rgba(55, 65, 81, 0.3)":"rgba(249, 250, 251, 0.5)"};
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .app-item:hover {
      background: ${t?"rgba(55, 65, 81, 0.5)":"rgba(249, 250, 251, 1)"};
      border-color: ${t?"rgba(75, 85, 99, 0.5)":"rgba(229, 231, 235, 1)"};
      transform: translateY(-1px);
      box-shadow: 0 4px 12px ${t?"rgba(0, 0, 0, 0.15)":"rgba(0, 0, 0, 0.05)"};
    }
    
    .app-info {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .app-logo-fallback {
      width: 16px;
      height: 16px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 3px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 7px;
      font-weight: bold;
      color: white;
      letter-spacing: 0.5px;
      flex-shrink: 0; /* Prevent shrinking */
    }
    
    .app-logo {
      width: 16px;
      height: 16px;
      border-radius: 3px;
      object-fit: contain;
      flex-shrink: 0; /* Prevent shrinking */
    }
    
    .app-name {
      font-size: 12px;
      font-weight: 500;
      color: ${t?"#f3f4f6":"#111827"};
    }
    
    .external-icon {
      color: ${t?"#6b7280":"#9ca3af"};
      font-size: 10px;
      opacity: 0.7;
      transition: all 0.2s ease;
    }
    
    .app-item:hover .external-icon {
      opacity: 1;
      transform: translateX(2px);
    }
    
    .footer {
      position: absolute;
      bottom: 8px;
      right: 24px;
    }
    
    .dismiss-btn {
      background: none;
      border: none;
      color: ${t?"#6b7280":"#9ca3af"};
      font-size: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      padding: 4px 8px;
      border-radius: 4px;
    }
    
    .dismiss-btn:hover {
      color: ${t?"#9ca3af":"#6b7280"};
      background: rgba(107, 114, 128, 0.05);
    }
    
    .empty-state {
      text-align: center;
      padding: 12px;
      color: ${t?"#6b7280":"#9ca3af"};
      font-size: 10px;
    }
    
    /* Auto-hide after delay */
    .modal-content.auto-hide {
      animation: fadeOutSlideRight 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    
    @keyframes fadeOutSlideRight {
      from { 
        opacity: 1; 
        transform: translateX(0) scale(1); 
      }
      to { 
        opacity: 0; 
        transform: translateX(40px) scale(0.95);
        pointer-events: none; 
      }
    }
  `;const r=document.createElement("div");r.innerHTML=v(e.apps),i.appendChild(a),i.appendChild(r.firstElementChild),document.body.appendChild(o),w(i),y(i),await b(m=>({...m,lastShown:Date.now(),lastShownDomain:n}))},y=e=>{c&&clearTimeout(c),c=window.setTimeout(()=>{if(!f&&o){const n=e.querySelector(".modal-content");n&&(n.classList.add("auto-hide"),setTimeout(()=>{o&&!f&&(o.remove(),o=null,c=null)},800))}},2e4)},d=()=>{f=!0,c&&(clearTimeout(c),c=null)},v=e=>{const n=e.map(l=>{const p=`https://www.google.com/s2/favicons?sz=32&domain_url=${encodeURIComponent(l.url)}`;return`
    <button class="app-item" data-url="${l.url}">
      <div class="app-info">
        <img 
          src="${p}" 
          class="app-logo" 
          alt="" 
          onerror="this.onerror=null; this.style.display='none'; this.nextSibling.style.display='flex';"
        />
        <div class="app-logo-fallback" style="display: none;">
          ${l.name.substring(0,2).toUpperCase()}
        </div>
        <span class="app-name">${l.name}</span>
      </div>
      <span class="external-icon">→</span>
    </button>
  `}).join("");return`
    <div class="modal-container">
      <div class="modal-content">
        <div class="modal-header">
          <button class="close-btn" id="close-modal">×</button>
        </div>
        
        <div class="main-question">
          <h2 class="question-text">How can I do this with AI?</h2>
          <div class="tools-dropdown">
            <button class="tools-trigger" id="tools-toggle">
              <span class="tools-trigger-text">AI Tools (${e.length})</span>
              <span class="tools-icon" id="tools-icon">▼</span>
            </button>
            <div class="tools-content" id="tools-content">
              ${e.length===0?'<div class="empty-state">No tools configured</div>':`<div class="app-list">${n}</div>`}
            </div>
          </div>
        </div>
        
        <div class="divider"></div>
        
        <div class="tools-section">
          <!-- Space for future features -->
        </div>
        
        <div class="footer">
          <button class="dismiss-btn" id="dismiss-modal">Dismiss</button>
        </div>
      </div>
    </div>
  `},w=e=>{const n=e.getElementById("close-modal"),l=e.getElementById("dismiss-modal"),p=()=>{if(d(),o){const r=e.querySelector(".modal-content");r&&(r.style.animation="fadeOutSlideRight 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards"),setTimeout(()=>{o&&(o.remove(),o=null)},300)}};n==null||n.addEventListener("click",()=>{d(),p()}),l==null||l.addEventListener("click",()=>{d(),p()});const g=e.getElementById("tools-toggle"),i=e.getElementById("tools-content"),s=e.getElementById("tools-icon");g==null||g.addEventListener("click",r=>{r.preventDefault(),d(),(i==null?void 0:i.classList.contains("open"))?(i==null||i.classList.remove("open"),s==null||s.classList.remove("open"),s&&(s.textContent="▼")):(i==null||i.classList.add("open"),s==null||s.classList.add("open"),s&&(s.textContent="▲"))}),e.querySelectorAll(".app-item").forEach(r=>{r.addEventListener("click",()=>{d();const m=r.getAttribute("data-url");m&&(window.open(m,"_blank","noopener,noreferrer"),p())})});const a=e.querySelector(".modal-content");a==null||a.addEventListener("mouseenter",()=>{d(),a.classList.remove("auto-hide")}),a==null||a.addEventListener("click",r=>{d(),r.stopPropagation()}),a==null||a.addEventListener("mousemove",()=>{f||d()})},k=()=>{console.log("Initializing content script..."),setTimeout(async()=>{console.log("Attempting to create modal...");try{await h()}catch(e){console.error("Error creating modal:",e)}},1500),chrome.storage.onChanged.addListener(e=>{if(console.log("Storage changes detected:",e),e["ai-prompt-reminder-state"]){const n=e["ai-prompt-reminder-state"].newValue;console.log("New extension state:",n),!(n!=null&&n.enabled)&&o&&(console.log("Extension disabled, removing modal"),o.remove(),o=null)}})};window===window.top?(console.log("Content script loaded in main frame"),k()):console.log("Content script loaded in iframe, skipping initialization");
